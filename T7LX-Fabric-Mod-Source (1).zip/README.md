# T7LX — Fabric client mod starter

This is a source project for a client-side Fabric mod menu for Minecraft 26.1.2.

## Included
- T7LX dark navy / black-blue click GUI
- Right Shift key mapping to open/close the menu
- One expandable module row: Freecam (toggle UI state)
- Client-only mod metadata and Java 25 configuration

## Important status
This first source build contains the menu and a working module toggle state. The Freecam row is currently a UI/module toggle scaffold; it does **not yet detach the camera or provide WASD flight**. That requires the version-specific camera implementation and testing in your exact Minecraft runtime. I have not compiled or tested this project here, so do not treat it as a ready-to-install `.jar`.

## Build
1. Install a Java 25 JDK.
2. Install Gradle 9.x (or open this folder in IntelliJ IDEA and let it import the Gradle project).
3. Open a terminal in this folder and run:
   - Windows: `gradle build`
4. If Gradle reports that the exact Minecraft/Fabric API artifact version is unavailable, check the current 26.1.2 versions at https://fabricmc.net/develop and update `gradle.properties`.
5. The jar, if the build succeeds, will be in `build/libs/`.

## Add more modules
Keep each feature as its own class under `src/client/java/gg/t7lx/client/modules/`, then add a row and toggle handler in `T7lxScreen`. Keep client-only features in the client source set.
