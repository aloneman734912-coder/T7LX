package gg.t7lx.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class T7lxClient implements ClientModInitializer {
    private static KeyMapping openMenuKey;
    private static boolean previousRightShift;
    private static boolean freecamEnabled;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("t7lx", "main"));
        openMenuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.t7lx.open_menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen instanceof T7lxScreen) {
                    client.setScreen(null);
                } else if (client.player != null) {
                    client.setScreen(new T7lxScreen());
                }
            }
            // Module state is centralized here so more modules can be registered later.
        });
    }

    public static boolean isFreecamEnabled() {
        return freecamEnabled;
    }

    public static void setFreecamEnabled(boolean enabled) {
        freecamEnabled = enabled;
        // The Freecam module implementation is intentionally isolated so it can be
        // expanded without changing the click-GUI/module registry.
    }
}
