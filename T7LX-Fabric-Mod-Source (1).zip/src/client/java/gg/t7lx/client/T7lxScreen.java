package gg.t7lx.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class T7lxScreen extends Screen {
    private static final int PANEL_W = 240;
    private static final int PANEL_H = 154;
    private int left;
    private int top;

    public T7lxScreen() {
        super(Component.literal("T7LX"));
    }

    @Override
    protected void init() {
        left = (this.width - PANEL_W) / 2;
        top = (this.height - PANEL_H) / 2;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);

        // Deep navy panel, blue border and subtle T7LX watermark.
        g.fill(left - 1, top - 1, left + PANEL_W + 1, top + PANEL_H + 1, 0xFF2379C9);
        g.fill(left, top, left + PANEL_W, top + PANEL_H, 0xFF101A2B);
        g.fill(left, top, left + PANEL_W, top + 28, 0xFF0B1322);
        g.drawString(this.font, "T7LX", left + 12, top + 10, 0xFF58B8FF, false);
        g.drawString(this.font, "CLIENT MODULES", left + 156, top + 11, 0xFF829BB5, false);

        // Watermark lettering.
        g.drawString(this.font, "T7LX", left + 144, top + 107, 0x302D8ACB, false);

        g.drawString(this.font, "MOVEMENT", left + 14, top + 43, 0xFF79BFFF, false);

        int rowTop = top + 61;
        boolean enabled = T7lxClient.isFreecamEnabled();
        boolean hovered = mouseX >= left + 12 && mouseX <= left + PANEL_W - 12
                && mouseY >= rowTop && mouseY <= rowTop + 30;
        g.fill(left + 10, rowTop, left + PANEL_W - 10, rowTop + 30,
                hovered ? 0xFF1B3552 : 0xFF17263A);
        g.drawString(this.font, "Freecam", left + 20, rowTop + 11, 0xFFEAF5FF, false);
        g.drawString(this.font, enabled ? "ON" : "OFF",
                left + PANEL_W - 45, rowTop + 11,
                enabled ? 0xFF55D6A0 : 0xFF8A9AAF, false);

        g.drawString(this.font, "Click a module to toggle it", left + 14, top + 112,
                0xFF829BB5, false);
        g.drawString(this.font, "RIGHT SHIFT  •  CLOSE", left + 14, top + 137,
                0xFF5A7897, false);

        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int rowTop = top + 61;
            if (mouseX >= left + 10 && mouseX <= left + PANEL_W - 10
                    && mouseY >= rowTop && mouseY <= rowTop + 30) {
                T7lxClient.setFreecamEnabled(!T7lxClient.isFreecamEnabled());
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
